create
    definer = root@localhost procedure get_all_customer()
begin
    select * from customers ;
end;

