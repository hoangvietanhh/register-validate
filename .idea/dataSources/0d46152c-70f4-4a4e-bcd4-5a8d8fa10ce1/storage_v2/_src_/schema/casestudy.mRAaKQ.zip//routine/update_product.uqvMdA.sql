create
    definer = root@localhost procedure update_product(IN id int, IN name varchar(50), IN provider varchar(50),
                                                      IN description varchar(255), IN price double, IN quantity int,
                                                      IN image varchar(255), IN categoryID1 int)
begin
update products
    set productName = name,provide = provider,
        productDescription=description,productPrice=price,
        productQuantity=quantity,productImage=image,categoryId=categoryID1
    where productID = id;

end;

