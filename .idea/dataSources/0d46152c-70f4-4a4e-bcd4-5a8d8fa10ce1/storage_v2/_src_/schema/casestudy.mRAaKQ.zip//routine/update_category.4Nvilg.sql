create
    definer = root@localhost procedure update_category(IN id int, IN name varchar(50), IN description varchar(50))
begin
    update category
        set categoryName = name,categoryDescription = description
    where categoryId = id;
end;

