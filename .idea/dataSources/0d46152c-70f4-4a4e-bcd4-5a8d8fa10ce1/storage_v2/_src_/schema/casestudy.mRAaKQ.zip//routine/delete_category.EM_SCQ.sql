create
    definer = root@localhost procedure delete_category(IN id int)
begin
    delete from category where categoryId = id;
end;

