create
    definer = root@localhost procedure create_order(IN customerid1 int, IN orderDate1 date, IN isShipped1 tinyint(1))
begin
    insert into orders(customerID, orderDate, isShipped) VALUES (customerid1,orderDate1,isShipped1);
end;

